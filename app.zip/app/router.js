import Ember from 'ember';
import config from './config/environment';

const Router = Ember.Router.extend({
  location: config.locationType,
  rootURL: config.rootURL
});

Router.map(function() {
  this.route('login');
  this.route('welcome');
  this.route('verifypwd');
  this.route('forgotpwd');
  this.route('info');
  this.route('modeldisplay',{path:'modeldisplay/:recordId'});
  this.route('sample');
  this.route('production');
});

export default Router;
