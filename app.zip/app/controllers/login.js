import Ember from 'ember';

export default Ember.Controller.extend({
    userName:'aravindh',
    password:'pass123',
    bool:false,
    check:function(){
        return this.bool;
    }.property('content.check'),
    
    
    MyModel:function(){
        return {recordId:1,name:'Aravindh Ravi'};
    }.property(),
    
    
});