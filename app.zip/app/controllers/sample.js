import Ember from 'ember';

export default Ember.Controller.extend({
   loggedInUser:"Aravindh",
   actions:{
    clickFunction:function(usr){
        alert("Hi:"+usr);
    }
   }
});